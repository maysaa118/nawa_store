

<?php $__env->startSection('content'); ?>
<header class="mb-4 d-flex">
    <h2 class="mb-4 fs-3">Trashed Products</h2>
    <div class="ml-auto">
        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-sm btn-primary">
            Products List</a>
    </div>
</header>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<table class="table">
    <thead>
        <tr>
            <th></th>
            <th>ID</th>
            <th>Name</th>
            <th>Deleted At</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="<?php echo e($product->image_url); ?>">
                    <img src="<?php echo e($product->image_url); ?>" width="60" alt="">
                </a>
            </td>
            <td><?php echo e($product->id); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->deleted_at); ?></td>
            <td>
                <form action="<?php echo e(route('products.restore', $product->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <button type="submit" class="btn btn-sm btn-primary"><i class="fas fa-trash-restore"></i> Restore</button>
                </form>
            </td>
            <td>
                <form action="<?php echo e(route('products.force-delete', $product->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i> Force Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($products->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\www\nawa-store\resources\views/admin/products/trashed.blade.php ENDPATH**/ ?>