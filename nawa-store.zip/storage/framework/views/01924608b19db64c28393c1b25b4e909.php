

<?php $__env->startSection('content'); ?>
<header class="mb-4 d-flex">
    <h2 class="mb-4 fs-3"><?php echo e($title); ?></h2>
    <div class="ml-auto">
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-sm btn-primary">
            + Create Product</a>
        <a href="<?php echo e(route('products.trashed')); ?>" class="btn btn-sm btn-danger">
            <i class="fas fa-trash"></i> View Trash</a>
    </div>
</header>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<form action="<?php echo e(URL::current()); ?>" method="get" class="form-inline">
    <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control mb-2 mr-2" placeholder="Search...">
    <select name="category_id" class="form-control mb-2 mr-2">
        <option value="">All categories</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($category->id); ?>" <?php if(request('category_id') == $category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <select name="status" class="form-control mb-2 mr-2">
        <option value="">Status</option>
        <?php $__currentLoopData = $status_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($value); ?>" <?php if(request('status') == $value): echo 'selected'; endif; ?>><?php echo e($text); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="number" name="price_min" value="<?php echo e(request('price_min')); ?>" class="form-control mb-2 mr-2" placeholder="Min Price">
    <input type="number" name="price_max" value="<?php echo e(request('price_max')); ?>" class="form-control mb-2 mr-2" placeholder="Max Price">
    <button type="submit" class="btn btn-dark">Filter</button>
</form>

<table class="table">
    <thead>
        <tr>
            <th></th>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Status</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="<?php echo e($product->image_url); ?>">
                    <img src="<?php echo e($product->image_url); ?>" width="60" alt="">
                </a>
            </td>
            <td><?php echo e($product->id); ?></td>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->category_name); ?></td>
            <td><?php echo e($product->price_formatted); ?></td>
            <td><?php echo e($product->status); ?></td>
            <td><a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-sm btn-outline-dark">
                <i class="far fa-edit"></i> Edit</a></td>
            <td>
                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($products->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\www\nawa-store\resources\views/admin/products/index.blade.php ENDPATH**/ ?>