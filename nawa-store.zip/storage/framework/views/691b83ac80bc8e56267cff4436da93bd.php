

<?php $__env->startSection('content'); ?>
<header class="mb-4 d-flex">
    <h2 class="mb-4 fs-3">Categories</h2>
    <div class="ml-auto">
        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-primary">
            + Create category</a>
    </div>
</header>
<?php if(session()->has('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<table class="table">
    <thead>
        <tr>
            <th></th>
            <th>ID</th>
            <th>Name</th>
            <th>Products #</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <a href="<?php echo e($category->image_url); ?>">
                    <img src="<?php echo e($category->image_url); ?>" width="60" alt="">
                </a>
            </td>
            <td><?php echo e($category->id); ?></td>
            <td><?php echo e($category->name); ?></td>
            <td><?php echo e($category->products_count); ?></td>
            <td><a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="btn btn-sm btn-outline-dark">
                <i class="far fa-edit"></i> Edit</a></td>
            <td>
                <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <button type="submit" class="btn btn-sm btn-danger"><i class="fas fa-trash"></i> Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php echo e($categories->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\www\nawa-store\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>