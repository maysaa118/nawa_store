<a class="nav-link" data-toggle="dropdown" href="#">
    <i class="far fa-bell"></i>
    <span class="unread-count badge badge-warning navbar-badge"><?php echo e($unread); ?></span>
</a>
<div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
    <span class="dropdown-header"><span class="unread-count"><?php echo e($unread); ?></span> Notifications</span>
    <div class="dropdown-divider"></div>
    <div id="notifications-list">
        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e($notification->data['link']); ?>?nid=<?php echo e($notification->id); ?>" class="dropdown-item">
            <i class="<?php echo e($notification->data['icon']); ?> mr-2"></i>
            <?php echo e($notification->data['body']); ?>

            <span class="float-right text-muted text-sm"><?php echo e($notification->created_at->diffForHumans(null, true, true)); ?></span>
        </a>
        <div class="dropdown-divider"></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <a href="#" class="dropdown-item dropdown-footer">See All Notifications</a>
</div><?php /**PATH G:\www\nawa-store\resources\views/components/admin/notifications.blade.php ENDPATH**/ ?>