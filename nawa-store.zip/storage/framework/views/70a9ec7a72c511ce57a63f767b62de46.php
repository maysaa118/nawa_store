

<?php $__env->startSection('content'); ?>
<h2 class="mb-4 fs-3">New Product</h2>

<form action="<?php echo e(route('products.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->make('admin.products._form', [
        'submit_label' => 'Create',
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\www\nawa-store\resources\views/admin/products/create.blade.php ENDPATH**/ ?>